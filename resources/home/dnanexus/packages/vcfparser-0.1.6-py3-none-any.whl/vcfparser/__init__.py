from vcfparser.vcf_parser import VcfParser
from vcfparser.vcf_writer import VCFWriter